﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class ViewForm : Form
    {
        public ViewForm()
        {
            InitializeComponent();
            this.Text = "ViewForm";
        }

        private void ViewForm_Load(object sender, EventArgs e)
        {

        }
    }
}
